from colordescriptor import ColorDescriptor
import glob
import cv2
import time
import os
import shutil
import csv
import matplotlib.pyplot as plt
import csv
import numpy as np
from sklearn import cluster
import BPTree as BPTree


dataset="datasetc"
filename="dataset.csv"
path="data"

def labeling(imgID):
	label = ''
	img=cv2.imread(dataset+"/"+imgID)
	#print(imgID)
	id = imgID[0:imgID.find('.jpg')]
	#print(path)
	if len(id) <= 2:
		label = 'people'
		if os.path.isdir(path+"/"+label):
			#print("directory exists")
			path1=path+"/"+label+"/"+imgID
			cv2.imwrite(path1,img)
		else:
			os.mkdir(path+"/"+label)
			path1=path+"/"+label+"/"+imgID
			cv2.imwrite(path1,img)
		label = 1
	
	if len(id) == 3:
		if int(id[0]) == 1:
			label = 'beach'
			if os.path.isdir(path+"/"+label):
				#print("directory exists")
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			else:
				os.mkdir(path+"/"+label)
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			label = 2

		elif int(id[0]) == 2:
			label = 'building'
			if os.path.isdir(path+"/"+label):
				#print("directory exists")
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			else:
				os.mkdir(path+"/"+label)
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			label = 3

		elif int(id[0]) == 3:
			label = 'bus'
			if os.path.isdir(path+"/"+label):
				#print("directory exists")
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			else:
				os.mkdir(path+"/"+label)
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			label = 4

		elif int(id[0]) == 4:
			label = 'dinosaur'
			if os.path.isdir(path+"/"+label):
				#print("directory exists")
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			else:
				os.mkdir(path+"/"+label)
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			label = 5

		elif int(id[0]) == 5:
			label = 'elephant'
			if os.path.isdir(path+"/"+label):
				#print("directory exists")
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			else:
				os.mkdir(path+"/"+label)
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			label = 6

		elif int(id[0]) == 6:
			label = 'flower'
			if os.path.isdir(path+"/"+label):
				#print("directory exists")
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			else:
				os.mkdir(path+"/"+label)
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			label = 7

		elif int(id[0]) == 7:
			label = 'horse'
			if os.path.isdir(path+"/"+label):
				#print("directory exists")
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			else:
				os.mkdir(path+"/"+label)
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			label = 8

		elif int(id[0]) == 8:
			label = 'mountain'
			if os.path.isdir(path+"/"+label):
				#print("directory exists")
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			else:
				os.mkdir(path+"/"+label)
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			label = 9

		elif int(id[0]) == 9:
			label = 'food'
			if os.path.isdir(path+"/"+label):
				#print("directory exists")
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			else:
				os.mkdir(path+"/"+label)
				path1=path+"/"+label+"/"+imgID
				cv2.imwrite(path1,img)
			label = 10

	
	#print (label)
	return label


def search(queryFeatures, limit,fs):
	# initialize our dictionary of results
	results = {}
	# open the index file for reading
	for m in range(len(fs)):
		mm=BPTree.ret(m)
		dd=mm.split(",")
		mm=mm.replace(dd[0]+",","")
		mm=mm.replace(dd[1]+",","")
		df=mm.split(",")
		features=[]
		for x in df:
			c=x.split(".")
			if len(c)>2:
				for n in range(len(c)):
					features.append(float("0."+c[n+1]))
					n=n+1
					if n>=len(c)-1:
						break
			else:
				features.append(float(x))
		d = chi2_distance(features, queryFeatures,1e-10)
		print (dd[0],' : ',d)
		results[dd[0]] = d
	results = sorted([(v, k) for (k, v) in results.items()])
	return results[:limit]

def chi2_distance(histA, histB, eps):
	# compute the chi-squared distance
	# value eps --> prevent divide by zero
	d = 0.5 * np.sum([ ( (a - b) ** 2 ) / (a + b + eps)
		for (a, b) in zip(histA, histB)])
		# return the chi-squared distance
	return d


def bpsearch(queryimage,limit):

	if os.path.isdir(path):
		shutil.rmtree(path, ignore_errors=True)
		os.mkdir(path)
	else:
		os.mkdir(path)
	
	# Labeling image ID to index file
	
	# Estimated timing
	start_time = time.time()
	
	# initialize the color descriptor
	# using 8 Hue bins, 12 Saturation bins, and 3 Value bins
	cd = ColorDescriptor((8, 12, 3))

	# open the output index file for writing
	output = open(filename, "w")

	i=0
	fs=[]

	# use glob to grab the image paths and loop over them
	for imagePath in glob.glob(dataset + "/*.jpg"):
		# extract the image ID (i.e. the unique filename) from the image
		# path and load the image itself
		#print ('imagePath: ',imagePath)
		imageID = imagePath[imagePath.rfind("\\") + 1:]
		#print ('imageID: ',imageID)
		image = cv2.imread(imagePath)
	
		# describe the image
		features = cd.describe(image)

		# write the features to file
		features = [str(f) for f in features]
		# output.write("%s,%s\n" % (imageID, ",".join(features)))
		label=labeling(imageID)
	
		s=str(imageID)+","+str(label)
		for f in features:
			s=s+","+f
	
		fs.append([i,s])
		i=i+1
	
	
		BPTree.bplustree(fs)
		output.write("%s,%s,%s\n" % (imageID,labeling(imageID),",".join(features)))
	print(len(fs))



	# close the index file
	output.close()

	# Result estimated time
	print("\n--- Estimated time execution: %s seconds ---" % round(time.time() - start_time, 4))

	#queryimage="queries/313.jpg"

	# Estimated timing
	start_time = time.time()

	# initialize the image descriptor
	# using 8 Hue bins, 12 Saturation bins, and 3 Value bins
	cd = ColorDescriptor((8, 12, 3))

	# load the query image and describe it
	query = cv2.imread(queryimage)
	features = cd.describe(query)
	#print(features)
	# perform the search

	results = search(features,limit,fs)
	print(results)
	
	print ('\n 10 Best Matching Result for Query: ', queryimage, '\n')
	print(results)
	i=0
	for (score, resultID) in results:
		# load the result image and display it
		i = i + 1
		result = cv2.imread( dataset+"/" + resultID)
		cv2.imwrite("result/" + str(i)+".jpg",result)
		
		cv2.imshow('Result #%s - %s'% (i, resultID), result)
		print (i,'.\t Score: ', score, '\t\t | image: ', resultID)
	
		cv2.waitKey(0)
