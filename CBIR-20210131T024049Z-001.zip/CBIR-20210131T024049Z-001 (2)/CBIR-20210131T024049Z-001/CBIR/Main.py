import tkinter as tk
from tkinter import Message ,Text
import csv
import numpy as np
from PIL import Image, ImageTk
import pandas as pd
import tkinter.ttk as ttk
import tkinter.font as font
from tkinter import filedialog
import tkinter.messagebox as tm
import PreprocessKmeans as pre
import KmeansSearch as KSearch
import BPTreeSearch as bpsearch

        	
bgcol="#fff5e6"
buttoncol="#ffc266"
fontcol="#804d00"
window = tk.Tk()
window.title("CBIR - KMEANS AND B+TREE")

 
window.geometry('1280x720')
window.configure(background=bgcol)
#window.attributes('-fullscreen', True)

window.grid_rowconfigure(0, weight=1)
window.grid_columnconfigure(0, weight=1)


message1 = tk.Label(window, text="CBIR - KMEANS AND B+TREE" ,bg=bgcol  ,fg="#996600"  ,width=50  ,height=3,font=('times', 30, 'italic bold underline')) 
message1.place(x=100, y=20)

lbl = tk.Label(window, text="Query Image",width=20  ,height=2  ,fg=fontcol  ,bg=buttoncol  ,font=('times', 15, ' bold ') ) 
lbl.place(x=100, y=200)

txt1 = tk.Entry(window,width=20,fg=fontcol  ,bg=buttoncol ,font=('times', 15, ' bold '))
txt1.place(x=400, y=215)

lbl2 = tk.Label(window, text="Enter Text",width=20  ,fg=fontcol  ,bg=buttoncol    ,height=2 ,font=('times', 15, ' bold ')) 
#lbl2.place(x=100, y=300)

txt2 = tk.Entry(window,width=20  ,fg=fontcol  ,bg=buttoncol ,font=('times', 15, ' bold ')  )
#txt2.place(x=400, y=315)

def QueryImage():
	txt1.delete(0, 'end') 
	print("add video")
	path=filedialog.askopenfilename()
	print(path)
	txt1.insert('end',path)
	if path !="":
		print("select image")
	else:
		tm.showinfo("Input error", "Select Query Image")	
	

def preprocess():
	print("preprocess")
	pre.process()
	tm.showinfo("Message", "Preprcess Finished and Trained Data Created")
	
	
def kmeansprocess():
	print("kmeans")
	a1=txt1.get()
	if a1 != "":
		print(a1)
		KSearch.search(a1,20)
	else:
		tm.showinfo("Input error", "Select Query Image")
	
def bptree():
	print("bptree")
	a1=txt1.get()
	if a1 != "":
		print(a1)
		bpsearch.bpsearch(a1,20)
	else:
		tm.showinfo("Input error", "Select Query Image")


browseButton = tk.Button(window, text="Browse Image", command=QueryImage  ,fg=fontcol  ,bg=buttoncol   ,width=15  ,height=1, activebackground = "Red" ,font=('times', 15, ' bold '))
browseButton.place(x=700, y=200)

kmeanspre = tk.Button(window, text="Preprocess", command=preprocess ,fg=fontcol  ,bg=buttoncol  ,width=15  ,height=1, activebackground = "Red" ,font=('times', 15, ' bold '))
kmeanspre.place(x=300, y=600)

kmeans1 = tk.Button(window, text="K-Means", command=kmeansprocess ,fg=fontcol  ,bg=buttoncol  ,width=15  ,height=1, activebackground = "Red" ,font=('times', 15, ' bold '))
kmeans1.place(x=500, y=600)

bptree = tk.Button(window, text="B+Tree", command=bptree ,fg=fontcol  ,bg=buttoncol  ,width=15  ,height=1, activebackground = "Red" ,font=('times', 15, ' bold '))
bptree.place(x=700, y=600)

quitWindow = tk.Button(window, text="Quit", command=window.destroy  ,fg=fontcol  ,bg=buttoncol   ,width=20  ,height=1, activebackground = "Red" ,font=('times', 15, ' bold '))
quitWindow.place(x=1000, y=600)

 
window.mainloop()
